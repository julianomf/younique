<div class="qodef-search-bottom-part qodef-search-button-section">
    <?php echo eiddo_qodef_get_button_html($button_parameters); ?>
</div>
