<div class="qodef-re-author-image">
	<?php echo qodef_re_get_author_image($author->ID, $author->roles, 'eiddo_qodef_square', '550'); ?>
</div>