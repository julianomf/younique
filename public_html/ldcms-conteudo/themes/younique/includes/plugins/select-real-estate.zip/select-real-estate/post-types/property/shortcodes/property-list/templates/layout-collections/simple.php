<div class="qodef-item-content-wrapper">
    <div class="qodef-item-image-section">
        <?php echo qodef_re_get_cpt_shortcode_module_template_part( 'property', 'property-list', 'parts/image', '', $params ); ?>
    </div>
    <div class="qodef-item-content">
        <?php echo qodef_re_get_cpt_shortcode_module_template_part( 'property', 'property-list', 'parts/title', '', $params ); ?>
        <?php echo qodef_re_get_cpt_shortcode_module_template_part( 'property', 'property-list', 'parts/price', '', $params ); ?>
    </div>
</div>