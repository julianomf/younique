<?php
$shortcode_params = qodef_re_get_search_page_sc_params($params);

echo eiddo_qodef_execute_shortcode('qodef_property_list', $shortcode_params);