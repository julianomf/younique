<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WC Order Item Package Data Store
 *
 * @version  3.0.0
 * @category Class
 * @author   WooCommerce
 */
class WC_Order_Item_Package_Data_Store extends WC_Order_Item_Qodef_Data_Store {


}