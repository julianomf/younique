<a class="qodef-re-add-to-compare" href="javascript:void(0)" title="<?php esc_attr_e('Remove property', 'select-real-estate') ?>" data-item-id="<?php echo esc_attr($id); ?>">
    <i class="icon_close" aria-hidden="true"></i>
</a>