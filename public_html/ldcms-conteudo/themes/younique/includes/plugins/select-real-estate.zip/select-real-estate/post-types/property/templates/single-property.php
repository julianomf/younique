<?php

get_header();

eiddo_qodef_get_title();

qodef_re_get_single_property();

get_footer();