<div class="qodef-clients-carousel-holder <?php echo esc_attr($holder_classes); ?>">
	<div class="qodef-cc-inner qodef-owl-slider" <?php echo eiddo_qodef_get_inline_attrs($carousel_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>