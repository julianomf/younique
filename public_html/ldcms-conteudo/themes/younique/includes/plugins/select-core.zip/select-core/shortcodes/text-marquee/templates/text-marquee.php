<div class="qodef-text-marquee" <?php echo eiddo_qodef_inline_style( $text_styles ); ?>>
	<span class="qodef-marquee-element qodef-original-text"><?php echo esc_html( $text ) ?></span>
	<span class="qodef-marquee-element qodef-aux-text"><?php echo esc_html( $text ) ?></span>
</div>  