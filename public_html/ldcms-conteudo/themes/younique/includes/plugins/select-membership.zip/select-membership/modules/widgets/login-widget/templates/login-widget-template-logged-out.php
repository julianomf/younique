<a href="#" class="qodef-login-opener">
    <?php if ( qodef_membership_theme_installed() ) {
        echo eiddo_qodef_icon_collections()->renderIcon( 'lnr-user', 'linear_icons' );
    } ?>
</a>